// Copyright David Abrahams 2001. Permission to copy, use,
// modify, sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.
#ifndef MODULE_DWA2001128_HPP
# define MODULE_DWA2001128_HPP

# include <boost/python/module_init.hpp>
# define BOOST_PYTHON_MODULE BOOST_PYTHON_MODULE_INIT

#endif // MODULE_DWA20011221_HPP
