// Copyright David Abrahams 2002. Permission to copy, use,
// modify, sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.
#ifndef NOT_SPECIFIED_DWA2002321_HPP
# define NOT_SPECIFIED_DWA2002321_HPP

namespace boost { namespace python { namespace detail { 

  struct not_specified {};

}}} // namespace boost::python::detail

#endif // NOT_SPECIFIED_DWA2002321_HPP
