// Copyright David Abrahams 2002. Permission to copy, use,
// modify, sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.
#ifndef MPL_LAMBDA_DWA2002122_HPP
# define MPL_LAMBDA_DWA2002122_HPP

// this header should go away soon
# include <boost/mpl/aux_/lambda_support.hpp>
# define BOOST_PYTHON_MPL_LAMBDA_SUPPORT BOOST_MPL_AUX_LAMBDA_SUPPORT

#endif // MPL_LAMBDA_DWA2002122_HPP
